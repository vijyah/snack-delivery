# Snack-Squad-A-Customizable-Snack-Ordering-and-Delivery-App

#SNACK APP DESIGNED BY PERUMAL @ SPKC

Google Developer Link : https://g.dev/Perumalmahe2023
 
Demo Video Link : https://drive.google.com/file/d/1RvZa0X8scAo9ICTlv_BnOQEk_mvpvL1n/view?usp=drivesdk
 
YouTube link - https://youtu.be/T1QuGs9qWdk
 

